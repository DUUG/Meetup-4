﻿using UnityEngine;
using System.Collections;

public class AutoArrayScript : MonoBehaviour {

    public Transform[] myTransform;
    private int counter = 0;

    // Use this for initialization
    void Start()
    {
        myTransform = new Transform[transform.childCount]; // count of objects that are achild

        foreach (Transform child in transform) // add to array
        {
            if (counter < myTransform.Length)
            {
                myTransform[counter] = child;
                counter++;
            }
        }
    }

    public void DoStuff()
    {
      // do stuff here
    }
}
