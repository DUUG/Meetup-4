﻿using UnityEngine;
using System.Collections;

public class CamScript : MonoBehaviour {

    [Range(0,400)]
	public float speed = 50.0F;
	private Vector3 lookDirection;

	public GameObject player;
	public GameObject vertPivot;
    public Transform myCamera;

    private float minimumY = -12F;
    private float maximumY = 60F;

    public bool camSwap = true;

    private float rotationY = 0;
	Quaternion originalRotation;

	void Start()
	{
		originalRotation = transform.localRotation; //set initaial rotation
	}

    // Rotate left and right
	void RotateHorz()
	{
		if(Input.GetAxis("RS_Horz") > 0.2f || Input.GetAxis("Mouse X") > 0.1f)
		{
			this.transform.Rotate(Vector3.up * speed * Time.deltaTime);
		}

		if(Input.GetAxis("RS_Horz") < -0.2f || Input.GetAxis("Mouse X") < -0.1f)
		{
            this.transform.Rotate(-Vector3.up * speed * Time.deltaTime);
		}
	}

	void RotateVert(bool mouseInput) // rotate up and down
	{
        if (mouseInput)
        {
            rotationY += Input.GetAxis("Mouse Y") * -1.2f;
        }
        else
        {
            rotationY += Input.GetAxis("RS_Vert") * 1.2f;
        }

		rotationY = ClampAngle (rotationY, minimumY, maximumY);

		Quaternion yQuaternion = Quaternion.AngleAxis (rotationY, Vector3.right);
		vertPivot.transform.localRotation = originalRotation * yQuaternion;
    }

    // clamp vertical movement
    public static float ClampAngle (float angle, float min, float max)
	{
		return Mathf.Clamp (angle, min, max);
	}

	// Update is called once per frame
	void LateUpdate()
	{
		this.gameObject.transform.position = player.transform.position;
	}

    //Simple flip using a bool
    void CamPos()
    {
        camSwap = !camSwap;

        if (camSwap)
        {
            myCamera.transform.localPosition = new Vector3(0, 0.5f, -6);
            minimumY = -12f;
            maximumY = 60f;
        }
        else
        {
            myCamera.transform.localPosition = new Vector3(.75f, 0.5f, -1.5f);
            minimumY = -30f;
            maximumY = 60f;
        }
    }

	void Update () 
	{
       

        RotateHorz();

        if (Input.GetAxis("RS_Vert") != 0) //detect joystick movement
        {
            RotateVert(false);
        }
        else if(Input.GetAxis("Mouse Y") != 0)// detect mouse movement
        {
            RotateVert(true);
        }

        if (Input.GetButtonDown("Fire2"))
        {
            CamPos();
        } 
    }
}
