﻿using UnityEngine;
using System.Collections;

public class HitBox : MonoBehaviour {

	void OnTriggerEnter(Collider other) 
	{
		if(other.tag == "Enemy")
		{
            other.gameObject.SetActive(false);
		}
	}
}
