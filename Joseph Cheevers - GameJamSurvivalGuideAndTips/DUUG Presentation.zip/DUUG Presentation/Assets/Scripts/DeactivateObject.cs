﻿using UnityEngine;
using System.Collections;

public class DeactivateObject : MonoBehaviour {

    // place this on any object you are using in the gameobject pool to return back into the pool

	public float timer = 1f;
	public bool returnToPool = true;

	void OnEnable () 
	{
		Invoke ("Destroy",timer);
	}
	
	void Destroy ()
	{
		if(returnToPool)
		{
			ObjectPool.instance.PoolObject(gameObject);
		}
		else
		{
			gameObject.SetActive(false);
		}
	}

	void OnDisable ()
	{
		CancelInvoke();
	}
}
