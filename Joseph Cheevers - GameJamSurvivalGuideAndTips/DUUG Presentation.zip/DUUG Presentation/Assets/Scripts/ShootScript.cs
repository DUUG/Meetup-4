﻿using UnityEngine;
using System.Collections;

public class ShootScript : MonoBehaviour {

	public Transform shootPos;
	public float speed = 40.0f;

    // takes prefab from pbject bool script
	void LaunchProjectile()
	{
        GameObject obj;
        obj = ObjectPool.instance.GetObjectForType("SnowBall", true);
		obj.transform.position = shootPos.position;
		obj.GetComponent<Rigidbody>().velocity = shootPos.transform.TransformDirection(Vector3.forward * speed);
	}

	void Update()
	{
        if (Input.GetButtonDown("Fire1"))
        {
            LaunchProjectile();
        }
	}
}
