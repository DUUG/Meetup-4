﻿using UnityEngine;
using System.Collections;

public class ProjectileScript : MonoBehaviour
{
    public AudioClip hitSFX;
    private new AudioSource audio;

    void Start()
    {
        audio = GetComponent<AudioSource>();
    }

    void Boom(Transform spawnPos)
    {
        GameObject obj;
        obj = ObjectPool.instance.GetObjectForType("BoomB", true);
        obj.transform.position = spawnPos.position;
    }

    void OnCollisionEnter(Collision other)
	{
        if (other.collider.tag == "Sign")
        {
            Destroy(other.gameObject, 0);
            Boom(other.transform);
            ObjectPool.instance.PoolObject(this.gameObject); // return projectile to game object pool
        }
        else if (!audio.isPlaying)
        {
            audio.PlayOneShot(hitSFX, 0.5f);
        }
	}
}
