﻿using UnityEngine;
using System.Collections;

[RequireComponent (typeof (AudioSource))]
[RequireComponent (typeof (BoxCollider))]

public class TriggerScript : MonoBehaviour {
    	
	public GameObject myGameObject;
	public AudioClip sound;

	public bool useFX;
	public string particleFXName;
	
	private new AudioSource audio;
	private Rigidbody rb;
	private BoxCollider bc;

	void Start()
	{
		audio = GetComponent<AudioSource> ();
		bc = GetComponent<BoxCollider>();

		audio.playOnAwake = false;
		bc.isTrigger = true;
	}

	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Player")
		{
			if(myGameObject != null)
			{
				myGameObject.SetActive (true);
			}
			
			if(sound != null)
			{
				if(!audio.isPlaying)
				{
					audio.PlayOneShot(sound);
				}
			}

			if(useFX) // particle FX from game Object pool
			{
				GameObject obj;
				obj = ObjectPool.instance.GetObjectForType(particleFXName, true);

                if (myGameObject != null)
                {
                    obj.transform.position = myGameObject.transform.position;
                }
                else
                {
                    obj.transform.position = this.transform.position;
                }
            }
		}
	}

	void OnTriggerExit(Collider other)
	{
		if(other.tag == "Player")
		{
			if(myGameObject != null)
			{
				myGameObject.SetActive(false);
			}
		}
	}
}
