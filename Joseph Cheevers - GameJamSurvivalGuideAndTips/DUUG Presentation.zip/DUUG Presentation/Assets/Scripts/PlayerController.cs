﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(AudioSource))]
//[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(CharacterController))]

public class PlayerController : MonoBehaviour 
{
	public enum MoveType
	{
		walking,
        dead
	};

	[System.Serializable]
	public class MoveSettings
	{
        [Range (0,20)]
		public float speed = 5F;

		public float jumpSpeed = 12.0F;
        public float turnSpeed = 30.0F;
        public float gravity = 0.5F;
		public float distToGrounded = 0.1f;
		public LayerMask groundMask;
	}

	[System.Serializable]
	public class SFX
	{
		public AudioClip jumpSFX;
		public AudioClip attackSFX;
	}

	[System.Serializable]
	public class MyObjects
	{
		public GameObject atkHitBox;
	}

    [System.Serializable]
    public class MyInputs
    {
        public string jumpPad;
        public string attackPad;

        public KeyCode jumpKey;
        public KeyCode attackKey;
    }

    public MoveType moveType;
	public MoveSettings moveSettings = new MoveSettings();
	public SFX sfx = new SFX();
	public MyObjects myObjects = new MyObjects();
    public MyInputs myInputs = new MyInputs();
    public Animator anim;
	
	//Inputs
	private float hor;	
	private float ver;	
	private Vector3 forward;
	private Vector3 right;

	private Vector3 moveDirection = Vector3.zero;	
	CharacterController controller;

    private new AudioSource audio;

	void Start()
	{
		controller = GetComponent<CharacterController>();
		audio = GetComponent<AudioSource>();
	}

    // check it play is grounded
	bool Grounded()
	{
		Ray ray = new Ray(new Vector3(transform.position.x, transform.position.y - controller.height/2 ,transform.position.z), Vector3.down);
		return Physics.Raycast (ray , moveSettings.distToGrounded, moveSettings.groundMask);
	}
	
    // set up user inputs
	void InputManager()
	{
		hor = Input.GetAxisRaw("Horizontal");
		ver = Input.GetAxisRaw("Vertical");
   	}
	
	void Animations()
	{
        anim.SetFloat("Movement",controller.velocity.sqrMagnitude);
		anim.SetBool("GroundedBool",Grounded ());
    }

	void CameraRelativeMovement()
	{
		forward = Camera.main.transform.TransformDirection(Vector3.forward);
		forward.y = 0;
		forward = forward.normalized;
		right = new Vector3(forward.z, 0, -forward.x);
	}

    // have the player face the direction of movement
	void LookAtDirection()
	{
		Vector3 localMoveDir = (hor * right  + ver * forward);
		
		if (localMoveDir.sqrMagnitude > 1f)
		{
			localMoveDir = localMoveDir.normalized;
		}
		
		if(localMoveDir != Vector3.zero)
		{
			transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(localMoveDir), moveSettings.turnSpeed * Time.smoothDeltaTime);
			transform.eulerAngles = new Vector3(0f, transform.eulerAngles.y, 0f);
		}
	}

    // Jumping & gravity
    void Jump()
	{  
		float downwardForce = -8f;

		if((Input.GetButtonDown(myInputs.jumpPad) || Input.GetKeyDown(myInputs.jumpKey)) && (Grounded () || controller.isGrounded))
		{
			moveDirection.y = moveSettings.jumpSpeed;
			audio.PlayOneShot (sfx.jumpSFX, 0.5f);
		}
		else if (controller.collisionFlags == CollisionFlags.Above)
		{
			moveDirection.y = downwardForce;
		}
		else if((!Input.GetButtonDown(myInputs.jumpPad) && !Input.GetKeyDown(myInputs.jumpKey)) && (Grounded () && controller.isGrounded))
		{
            moveDirection.y = downwardForce;
        }
		else
		{
            if (moveDirection.y < moveSettings.gravity)
            {
                moveDirection.y -= moveSettings.gravity * Time.deltaTime;
            }
            else
            {
                moveDirection.y = moveSettings.gravity;
            }			
		}
	}

    //player Movement
    void MoveController() 
	{
		switch (moveType) 
		{
		case MoveType.walking:

			LookAtDirection();
			CameraRelativeMovement();

			if(Grounded()) 
			{
				moveDirection = (hor * right  + ver * forward);
				moveDirection = moveDirection * moveSettings.speed;

				if(Input.GetButtonDown(myInputs.attackPad) || Input.GetKeyDown(myInputs.attackKey))
				{
					Attack();
				}
			}
			else 
			{
				moveDirection.x = (hor * right.x + ver * forward.x) * moveSettings.speed;
				moveDirection.z = (ver * forward.z + hor * right.z) * moveSettings.speed;
			}

            Jump();

          break;
            case MoveType.dead:

                // Do stuff here if player is dead

             break;
		default:

			break;
		}

        controller.Move (moveDirection * Time.deltaTime);
	}

	void Attack() // turn on hitbox
	{
        if (!audio.isPlaying)
        {
            audio.PlayOneShot(sfx.attackSFX, 0.5f);
            myObjects.atkHitBox.SetActive(true);
            StartCoroutine(WaitCR(0.3f, "atkBox"));
        }
    }

	void Update() 
	{
		InputManager ();
        Animations();

        if (Input.GetButtonDown(myInputs.attackPad))
        {
            Attack();
        }

        MoveController();
    }

	IEnumerator WaitCR (float delay, string type)
	{
		yield return new WaitForSeconds(delay);

        if (type =="atkBox")
		{
			myObjects.atkHitBox.SetActive(false);
		}
	}
}